library(testthat)
library(msuopa)

test_check("msuopa")
