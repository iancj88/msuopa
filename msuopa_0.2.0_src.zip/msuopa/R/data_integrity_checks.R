#' get_mus_professor_discrepencies
#'
#' Check for Professors without the MUS checkbox. Requires a Banner login. Uses the
#' OPA Banner snapshot from the date called. May later update to check for Rank
#' records rather than just 'Professor' in the title.
#'
#'
#' @return a dateframe containing snapshot info for jobs with 'Professor' in
#' the position title and no MUS checkbox
#' @export
get_mus_professor_discrepencies <- function() {
  # get a snapsht from the current date
  curr_snpsht <- msuopa::get_banner_snapshots(debug_date = Sys.Date(),
                                              include_leave = TRUE)

  # filter to only look at people with no MUS and with 'Professor' in the
  # position title

  suspect_records <- curr_snpsht[[1]]
  suspect_records <- dplyr::filter(suspect_records,
                                   MUS_CONTRACT == "N",
                                   grepl(pattern = "Professor",
                                         x = POSITION_TITLE,
                                         ignore.case = TRUE))

  return(suspect_records)
}


# Check for classifieds with position titles not in MUS payplan
#
