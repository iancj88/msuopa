#' msuopa: A package for common OPA related data tasks
#'
#'
#'
#' @section Foo functions:
#' The foo functions ...
#'
#' @docType package
#' @name foo
NULL

