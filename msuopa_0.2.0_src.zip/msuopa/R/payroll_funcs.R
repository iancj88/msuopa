#
#
#
# # compile summary of total payments to employees from payroll data
# proll <- msuopa::get_payroll_data()
#
# proll$date <- ISOdate(year = proll$`True Year`,
#                       month = proll$`True Month`,
#                       day = 1)
# proll$fy <- msuopa::compute_fiscal_year(proll$date)
#
# proll_17 <- dplyr::filter(proll, fy == 2017)
#
# # now create summaries by person
# pay_summary <- proll_17 %>%
#   dplyr::group_by(GID) %>%
#   dplyr::filter(`Earn Code` %in% c("REG", "ANN", "SIC")) %>%
#   dplyr::summarise(total_comp = sum(Amount)) %>%
#   dplyr::arrange(desc(total_comp))
#
# # rejoin names
# names <- dplyr::select(proll_17,
#                        GID,
#                        Name)
# pay_summary <- dplyr::left_join(pay_summary,
#                          names,
#                          by = "GID") %>%
#   dplyr::distinct()
#
# # compute presidents payments
# cruzado_16 <- dplyr::filter(proll,
#                             fy == 2016,
#                             GID == "-01939403")
# unique(cruzado_17$`Earn Code`)
